<div class="form-group">
	{!! Form::label('Комментарий') !!}
	{!! Form::textarea ('body', null, ['class'=>'form-control']) !!}
</div>