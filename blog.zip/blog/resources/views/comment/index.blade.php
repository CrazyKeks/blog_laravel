	@foreach($post->comments()->get() as $comment)
		<article>
			<p>{{$comment->author->name}}</p>
			<p>{{$comment->body}}</p>
			<p>{{$comment->post->id}}</p>
			<p>
				Публикация: {{$comment->created_at}}
			</p> 
		</article>
	 	<div class="container">
	 	</div>
	@endforeach





