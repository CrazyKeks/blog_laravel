
<div class="form-group">
	{!! Form::label('Тема') !!}
	{!! Form::text ('title', null, ['class'=>'form-control']) !!}
</div>
<div class="form-group">
	{!! Form::label('Краткий заголовок') !!}
	{!! Form::text ('slug', null, ['class'=>'form-control']) !!}
</div>
<div class="form-group">
	{!! Form::label('Текст') !!}
	{!! Form::textarea ('body', null, ['class'=>'form-control']) !!}
</div>
<div class="form-group">
	{!! Form::label('Опубликовать') !!}
	{!! Form::checkbox ('active', true, ['class'=>'form-control'] ) !!}
</div>
<div class="form-group">
	{!! Form::label('Публикация') !!}
	{!! Form::input ('date', 'created_at', date('Y-m-d'), ['class'=>'form-control'] ) !!}
</div>

	