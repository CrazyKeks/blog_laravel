@extends('layouts.app')

@section('content')

	{!! Form::open(array('url' => route('post.edit', $post->id),'method'=>'GET')) !!}
		<div class="content">

			<div class="content">
				<h1><i>{{$post->title,['class'=>'btn btn-primary col-md-5'] }}</i></h1>  {!! Form::submit('Редактировать', ['class'=>'btn btn-primary col-md-offset-10']) !!}
			</div>

			<p>{{$post->slug}}</p>
			
			<p>{{$post->body}}</p>

			<p>{{$post->created_at}}</p>
			<br>
			<br>
			

		</div>

	{!! Form::close() !!}  


		<br>
		<p>Все комментарии</p>

			
		@include('comment.index')


		{!! Form::open(array('url' => route('comment.store'),'method'=>'POST')) !!}
         {{!! Form::text('from_user', $post->user_id, ['class'=>'hidden']) !!}}
         {{!! Form::text('on_post', $post->id, ['class'=>'hidden']) !!}}

			@include('comment.create')
			
		{!! Form::submit('Отправить', ['class'=>'btn btn-primary']) !!}
		{!! Form::close() !!}
		

		
		
@endsection
