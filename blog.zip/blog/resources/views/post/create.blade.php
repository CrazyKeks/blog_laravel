@extends('layouts.app')
 
@section('content')

	<h1>Создание поста</h1>

	{!! Form::open(array('url' => route('post.store'),'method'=>'POST')) !!}

		@include('post._form')
	{{Form::text('user_id',Auth::user()->id,['class'=>'hidden'])}}
	{!! Form::submit('Отправить', ['class'=>'btn btn-primary']) !!}
	{!! Form::close() !!}
	
@endsection


