@extends('layouts.app')

 
@section('content')
    @foreach($posts as $post)
    {!! Form::open(array('url' => route('post.show', $post->id),'method'=>'GET')) !!}
        <article>
            <h2> {{$post->title}} </h2>
            <p>  {{$post->slug}} </p>
            <p>  {{$post->body}} </p>
            <p>{{ $post->created_at->format('M d,Y \a\t h:i a') }} By <a href="{{ url('/user/'.$post->author_id)}}">{{ $post->author->name }}</a></p>
            {!! Form::submit('Читать далее...') !!}
            {!! Form::close() !!} 
        </article>
        <div class="container">
        </div>
    @endforeach
    <div> 
    <br>
        @if(!Auth::guest() && ($post->author_id == Auth::user()->id || Auth::user()->is_admin()))
             @if($post->active == '1')
                {!! link_to_route('post.create','новый пост', [], ["class" => "btn btn-primary" ]) !!}
             @else
             @endif
        @endif
    </div>
@endsection