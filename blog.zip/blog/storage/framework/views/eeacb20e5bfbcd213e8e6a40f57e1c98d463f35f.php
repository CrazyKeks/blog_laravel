<div class="form-group">
	<?php echo Form::label('Комментарий'); ?>

	<?php echo Form::textarea ('body', null, ['class'=>'form-control']); ?>

</div>