<?php $__env->startSection('content'); ?>

	<?php echo Form::open(array('url' => route('post.edit', $post->id),'method'=>'GET')); ?>

		<div class="content">

			<div class="content">
				<h1><i><?php echo e($post->title,['class'=>'btn btn-primary col-md-5']); ?></i></h1>  <?php echo Form::submit('Редактировать', ['class'=>'btn btn-primary col-md-offset-10']); ?>

			</div>

			<p><?php echo e($post->slug); ?></p>
			
			<p><?php echo e($post->body); ?></p>

			<p><?php echo e($post->created_at); ?></p>
			<br>
			<br>
			

		</div>

	<?php echo Form::close(); ?>  


		<br>
		<p>Все комментарии</p>

			
		<?php echo $__env->make('comment.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		<?php echo Form::open(array('url' => route('comment.store'),'method'=>'POST')); ?>

         {<?php echo Form::text('from_user', $post->user_id, ['class'=>'hidden']); ?>}
         {<?php echo Form::text('on_post', $post->id, ['class'=>'hidden']); ?>}

			<?php echo $__env->make('comment.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
		<?php echo Form::submit('Отправить', ['class'=>'btn btn-primary']); ?>

		<?php echo Form::close(); ?>

		

		
		
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>