 
<?php $__env->startSection('content'); ?>

	<h1>Создание поста</h1>
	 	 

	 	 <?php echo Form::model($post, [
	 	 'method' => 'PATCH',
	 	 'url' => [ route('post.update', array($post->id))],
	 	 ]); ?>


		<?php echo $__env->make('post._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo Form::submit('Отправить', ['class'=>'btn btn-primary']); ?>


		<?php echo Form::close(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>