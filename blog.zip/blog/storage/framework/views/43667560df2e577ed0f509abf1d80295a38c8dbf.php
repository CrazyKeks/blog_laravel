	<?php foreach($post->comments()->get() as $comment): ?>
		<article>
			<p><?php echo e($comment->author->name); ?></p>
			<p><?php echo e($comment->body); ?></p>
			<p><?php echo e($comment->post->id); ?></p>
			<p>
				Публикация: <?php echo e($comment->created_at); ?>

			</p> 
		</article>
	 	<div class="container">
	 	</div>
	<?php endforeach; ?>





