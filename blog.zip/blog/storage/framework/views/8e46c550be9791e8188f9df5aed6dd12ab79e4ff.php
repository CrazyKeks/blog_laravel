 
<?php $__env->startSection('content'); ?>

	<h1>Создание поста</h1>

	<?php echo Form::open(array('url' => route('post.store'),'method'=>'POST')); ?>


		<?php echo $__env->make('post._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo e(Form::text('user_id',Auth::user()->id,['class'=>'hidden'])); ?>

	<?php echo Form::submit('Отправить', ['class'=>'btn btn-primary']); ?>

	<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>