<?php echo Form::open(array('url' => 'comment','method'=>'POST')); ?>


<div class="form-group">
	<?php echo Form::textarea ('content', null, ['class'=>'form-control']); ?>

</div>

<?php echo Form::submit('Оставить комментарий', ['class'=>'btn btn-primary']); ?>


<br>

<?php echo Form::close(); ?>