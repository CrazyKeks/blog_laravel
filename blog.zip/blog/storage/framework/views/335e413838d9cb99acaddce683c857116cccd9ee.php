
<div class="form-group">
	<?php echo Form::label('Тема'); ?>

	<?php echo Form::text ('title', null, ['class'=>'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('Краткий заголовок'); ?>

	<?php echo Form::text ('slug', null, ['class'=>'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('Текст'); ?>

	<?php echo Form::textarea ('body', null, ['class'=>'form-control']); ?>

</div>
<div class="form-group">
	<?php echo Form::label('Опубликовать'); ?>

	<?php echo Form::checkbox ('active', true, ['class'=>'form-control'] ); ?>

</div>
<div class="form-group">
	<?php echo Form::label('Публикация'); ?>

	<?php echo Form::input ('date', 'created_at', date('Y-m-d'), ['class'=>'form-control'] ); ?>

</div>

	