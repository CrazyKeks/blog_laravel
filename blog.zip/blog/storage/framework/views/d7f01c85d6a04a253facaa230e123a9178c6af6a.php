<?php $__env->startSection('content'); ?>
	<?php foreach($posts as $post): ?>
	<?php echo Form::open(array('url' => route('post.show', $post->id),'method'=>'GET')); ?>

		<article>
			<h2> <?php echo e($post->title); ?> </h2>
			<p>  <?php echo e($post->slug); ?> </p>
			<p>  <?php echo e($post->body); ?> </p>
			<p>
				Публикация: <?php echo e($post->created_at); ?>

			</p>
			<?php echo Form::submit('Читать далее...'); ?>

			<?php echo Form::close(); ?> 
		</article>
	 	<div class="container">
	 	</div>
	<?php endforeach; ?>
	<div> 
	<br>
		
		<?php echo link_to_route('post.create','новый пост', [], ["class" => "btn btn-primary" ]); ?>

	
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>